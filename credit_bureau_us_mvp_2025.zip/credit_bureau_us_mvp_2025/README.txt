# US Credit Bureau Synthetic MVP (2025 compliant)
Generated: 2025-10-05
Records: 1200 consumers, Metro 2®-style sections.

Key compliance choices:
- Public records: bankruptcies only
- Collections: non-medical only (no medical debt)
- Inquiries: includes hard/soft + permissible purpose
- Unified feature view: feature_view.csv

Columns in feature_view.csv:
consumer_id, dob, primary_state, fico8, vantage4, score_date, tradelines_total, tradelines_open, revolving_limit_sum, revolving_balance_sum, revolving_utilization, total_balance_sum, delinq_24mo_count, worst_delinq_24mo, inquiries_12mo_hard, inquiries_12mo_soft, has_collection, collection_balance_total, has_bankruptcy, bankruptcy_most_recent, months_since_oldest_account, avg_account_age_months
